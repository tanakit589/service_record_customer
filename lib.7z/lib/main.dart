import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/material/colors.dart';
import 'package:service_record/pages/Checklist_istat1/Page1.dart';
import 'package:service_record/pages/CreateJob/Page1.dart';
import 'package:service_record/pages/HomePage.dart';
import 'package:service_record/pages/Loginpage.dart';
import 'package:service_record/pages/add_device/List_Device.dart';
import 'package:service_record/pages/add_device/List_Hospital.dart';
import 'package:service_record/pages/add_device/page1.dart';

import 'package:service_record/pages/service_report/aaa.dart';
import 'package:service_record/pages/service_report/service_reportpage1.dart';
import 'package:service_record/pages/service_report/homepage_report.dart';
import 'package:service_record/pages/service_report/service_reportpage2.dart';
import 'package:provider/provider.dart';
import 'package:service_record/pages/service_report/service_reportpage3.dart';

import 'firebase_options.dart';

void main() async {
   WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(MultiProvider(
    providers: [
      ChangeNotifierProvider(create: (context) => ListTypeServiceModel()),
      ChangeNotifierProvider(create: (context) => CustomerProfileModel()),
      ChangeNotifierProvider(create: (context) => DetailRepotModel()),
      ChangeNotifierProvider(create: (context) => AddDeviceModel()),
      ChangeNotifierProvider(create: (context) => CreateJobmodel()),
      ChangeNotifierProvider(create: (context) => SparePartModel()),
      ChangeNotifierProvider(create: (context) => ProfileModel()),
      ChangeNotifierProvider(create: (context) => HospitalModel()),
       ChangeNotifierProvider(create: (context) => DeviceModel()),
    ],
    child: const MyApp(),
  ));
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(primarySwatch: Colors.green),
      initialRoute: '/login',
      routes: {
        //'/1': (context) => HomePage(),
        '/0': (context) => HomePageReport(),
        '/1': (context) => service_reportpage1(),
        '/2':(context) => Checklist_istat_Page1(),
        //'/3': (context) => AddDevice_Page1(),
       // '/4': (context) => service_reportPage3(),
        '/login': (context) => LoginPage(),
        '/homepage':(context) => HomePage(),
      },
    );
  }
}
