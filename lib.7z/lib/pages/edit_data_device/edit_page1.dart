import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:service_record/pages/Loginpage.dart';
import 'package:service_record/widgets/drawer.dart';

import 'edit_page2.dart';

class EditPage1 extends StatefulWidget {
  @override
  State<EditPage1> createState() => _EditPage1State();
}

class _EditPage1State extends State<EditPage1> {
  final _formkey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: drawer(),
      appBar: AppBar(
        title: Text('Verify User'),
      ),
      body: Consumer<ProfileModel>(builder: (context, value, child) {
        return Form(
          key: _formkey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text('Edit device information',style: TextStyle(fontSize: 20),),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextFormField(
                  decoration: InputDecoration(
                      labelText: 'UserName',
                      border: OutlineInputBorder(),
                      hintText: 'UserName'),
                  initialValue: '${value.username}',
                  readOnly: true,
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextFormField(
                  decoration: InputDecoration(
                      labelText: 'Password',
                      border: OutlineInputBorder(),
                      hintText: 'Password'),
                 validator: (value1) {
                      if (value1 == null || value1.isEmpty) {
                        return 'Please enter your password  ';
                      }else if (value1 != '${value.password}') {
                        return 'Confirm password not matching';
                      } else {
                        return null;
                      }
                    },
                ),
              ),
              Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: ElevatedButton(
                            onPressed: () {
                              if (_formkey.currentState!.validate()) {
                                _formkey.currentState!.save();
                                
        
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => EditPage2()));
                              }
                            },
                            child: Text('next')),
                      ),
            ],
        
          ),
        );
      }),
    );
  }
}
