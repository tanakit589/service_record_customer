import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:service_record/widgets/drawer.dart';

class EditPage2 extends StatefulWidget {
  @override
  State<EditPage2> createState() => _EditPage2State();
}

class _EditPage2State extends State<EditPage2> {
  TextEditingController _date = TextEditingController();
  final _formkey = GlobalKey<FormState>();
  late String date;
  late String _sn;
  late String _DeviceName;
  late String _model;
  late String _Manufacturer;
  late String _hospital;
  late String _Department;
  late String _Contact;
  bool _lock = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: drawer(),
      appBar: AppBar(
        title: Text('Edit device information'),
      ),
      body: SingleChildScrollView(
        child: Form(
          key: _formkey,
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextFormField(
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'SN',
                    hintText: 'SN',
                    suffixIcon: IconButton(
                      icon: Icon(Icons.search),
                      onPressed: () {
                        setState(() {});
                      },
                    ),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'please enter SN';
                    }
                    return null;
                  },
                  onSaved: (newValue) => _sn = newValue!,
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextFormField(
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Device Name',
                    hintText: 'Device Name',
                  ),
                  readOnly: _lock,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'please enter device name';
                    }
                    return null;
                  },
                  onSaved: (newValue) => _DeviceName = newValue!,
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextFormField(
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Model',
                    hintText: 'Model',
                  ),
                  readOnly: _lock,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'please enter Model';
                    }
                    return null;
                  },
                  onSaved: (newValue) => _model = newValue!,
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextFormField(
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Manufacturer',
                    hintText: 'Manufacturer',
                  ),
                  readOnly: _lock,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'please enter Manufacturer';
                    }
                    return null;
                  },
                  onSaved: (newValue) => _Manufacturer = newValue!,
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextFormField(
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Hospital',
                    hintText: 'Hospital',
                  ),
                  readOnly: _lock,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'please enter Hospital';
                    }
                    return null;
                  },
                  onSaved: (newValue) => _hospital = newValue!,
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextFormField(
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Department',
                    hintText: 'Department',
                  ),
                  readOnly: _lock,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'please enter department';
                    }
                    return null;
                  },
                  onSaved: (newValue) => _Department = newValue!,
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextFormField(
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Contact',
                    hintText: 'Contact',
                  ),
                  readOnly: _lock,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'please enter contact';
                    }
                    return null;
                  },
                  onSaved: (newValue) => _Contact = newValue!,
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextFormField(
                  readOnly: _lock,
                  controller: _date,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Warranty',
                    suffixIcon: IconButton(
                      onPressed: () async {
                        DateTime? pickedate = await showDatePicker(
                            context: context,
                            initialDate: DateTime.now(),
                            firstDate: DateTime(1900),
                            lastDate: DateTime(2101));
                        if (pickedate != null) {
                          setState(
                            () {
                              _date.text =
                                  DateFormat('dd/MM/yyyy').format(pickedate);
                            },
                          );
                        }
                      },
                      icon: Icon(Icons.calendar_today_rounded),
                    ),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please select warranty date';
                    }
                    return null;
                  },
                  onSaved: (newValue) {
                    date = newValue!;
                  },
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: ElevatedButton(
                        onPressed: () {
                          // if (_formkey.currentState!.validate()) {
                          //   _formkey.currentState!.save();
                            // context.read<AddDeviceModel>()
                            // ..sn = _sn
                            // ..Department = _Department
                            // ..Contact = _Contact
                            // ..hospital= _hospital
                            // ..DeviceName= _DeviceName;

                            Navigator.pop(context);
                         // }
                        },
                        child: Text('Submit')),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: ElevatedButton(
                        onPressed: () {
                          setState(() {
                            _lock = !_lock; //toggling the value received
                            print(_lock);
                          });
                        },
                        child: _lock ? Text('lock') : Text('unlock')),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
