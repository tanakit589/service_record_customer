import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/material/colors.dart';
import 'package:service_record/pages/CreateJob/Page1.dart';
import 'package:service_record/pages/Job_Data.dart';
import 'package:service_record/pages/service_report/homepage_report.dart';
import 'package:service_record/pages/service_report/service_reportpage1.dart';

import 'package:service_record/pages/service_report/service_reportpage2.dart';
import 'package:service_record/widgets/drawer.dart';
import 'package:provider/provider.dart';

class HomePage extends StatefulWidget {
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int itemCount = 10;
  bool a = false;
  Future refresh() async {
    Future<void>.delayed(const Duration(seconds: 2));
    setState(() {
      itemCount = 20 + itemCount;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: drawer(),
      appBar: AppBar(
        title: Text(
          'Home',
          style: TextStyle(
            fontSize: 24,
          ),
        ),
        actions: [
          GestureDetector(
              child: IconButton(
            onPressed: () {
           
            
            },
            icon: Icon(Icons.notifications_sharp),
            iconSize: 30,
          )),
          GestureDetector(
              child: IconButton(
            onPressed: () {},
            icon: Icon(Icons.person),
            iconSize: 30,
          )),
        ],
      ),
      backgroundColor: Color.fromARGB(255, 255, 255, 255),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 10.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    InkWell(
                      onTap: () {},
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(
                            height: 60,
                            width: 100,
                            decoration: BoxDecoration(border: Border.all()),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text('Complete',
                                    style: TextStyle(
                                        fontSize: 16,
                                        color:
                                            Color.fromARGB(255, 25, 176, 5))),
                                Text('10')
                              ],
                            )),
                      ),
                    ),
                    InkWell(
                      onTap: () {},
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(
                            height: 60,
                            width: 100,
                            decoration: BoxDecoration(border: Border.all()),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text('In Progress',
                                    style: TextStyle(
                                        fontSize: 16,
                                        color:
                                            Color.fromARGB(255, 145, 130, 3))),
                                Text('2')
                              ],
                            )),
                      ),
                    ),
                    InkWell(
                      onTap: () {},
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(
                            height: 60,
                            width: 100,
                            decoration: BoxDecoration(border: Border.all()),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text('Quotation',
                                    style: TextStyle(
                                        fontSize: 16,
                                        color: Color.fromARGB(255, 2, 3, 19))),
                                Text('1'),
                              ],
                            )),
                      ),
                    ),
                  ],
                ),
              ),
              Divider(
                color: Colors.white,
                height: 10,
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text('Pending', style: TextStyle(fontSize: 20)),
              ),
              Container(
                height: 250,
                decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Color.fromARGB(255, 255, 255, 255),
                        blurRadius: 10,
                      ),
                    ],
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.black, width: 1)),
                child: RefreshIndicator(
                  onRefresh: refresh,
                  strokeWidth: 2,
                  color: Colors.blue,
                  child: ListView.separated(
                    itemCount: itemCount,
                    shrinkWrap: true,
                    separatorBuilder: (BuildContext context, int index) =>
                        const Divider(
                     color: Colors.black,
                    ),
                    itemBuilder: (BuildContext context, int index) {
                       
                      return ListTile(
                        onTap: () { Navigator.push(context,
                  MaterialPageRoute(builder: (context)=> JobData()));
                  },
                        title: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            if(index == 0)...[
                             Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                               children: [
                                 Text('TUH'),
                                 Text('iSTAT1  SN : 111111'),
                                 Text('OR'),
                               ],
                             ),
                            ] else if (index != 0)...[
                             Text('job ${index + 1}'),
                            ]
                            
                            
                          ],
                        ),
                        trailing: IconButton(
                          onPressed: () {
                   Navigator.push(context,
                  MaterialPageRoute(builder: (context)=> HomePageReport()));
                          },
                          icon: Icon(Icons.description),
                        ),
                      );
                    },
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: Text('latest', style: TextStyle(fontSize: 20)),
              ),
              SafeArea(
                child: Container(
                  height: 200,
                  decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Color.fromARGB(255, 255, 255, 255),
                        blurRadius: 10,
                      ),
                    ],
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.black, width: 1)),
                  child: ListView.separated(
                    itemCount: 5,
                    shrinkWrap: true,
                    separatorBuilder: (BuildContext context, int index) =>
                        const Divider(
                      color: Colors.black,
                    ),
                    itemBuilder: (BuildContext context, int index) {
                      return ListTile(
                        onTap: () {},
                        title: Text('job ${index + 1}'),
                        trailing: IconButton(
                          onPressed: () {
                           
       
                          },
                          icon: Icon(Icons.description),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {Navigator.push(context,
                  MaterialPageRoute(builder: (context)=> CreateJobPage1()));},
        tooltip: 'Find error code',
        child: const Icon(Icons.search),
      ),
    );
  }
}
