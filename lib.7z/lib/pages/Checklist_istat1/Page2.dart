import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:service_record/pages/Checklist_istat1/Page3.dart';

class Checklist_istat_Page2 extends StatefulWidget {
  @override
  State<Checklist_istat_Page2> createState() => _Checklist_istat_Page2State();
}

class _Checklist_istat_Page2State extends State<Checklist_istat_Page2> {
  final _formkey = GlobalKey<FormState>();


  bool _No1 = false;
  bool _No2_J = false;
  bool _No2_C = false;
  bool _No3_a = false;
  bool _No3_b = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Checklist Page 2'),
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Center(child: Text('i-STAT1')),
          )
        ],
      ),
      body: SingleChildScrollView(
        child: Form(
          key: _formkey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 10,left: 2,right: 2),
                child: Container(
                  decoration: BoxDecoration(border: Border.all()),
                  child: CheckboxListTile(
                    title: Text('1. Clean the external surface'),
                    value: _No1,
                    onChanged: ((value) {
                      setState(() {
                        _No1 = value!;
                      });
                    }),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text('2. Software version '),
              ),
              Padding(
                padding: const EdgeInsets.all(2.0),
                child: Table(
                  border: TableBorder.symmetric(outside: BorderSide(width: 1) ),
                  children: <TableRow>[
                  TableRow(
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: TextFormField(
                          // initialValue: 'TUH',
                          //  readOnly: true,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(),
                            labelText: 'JAMS',
                            hintText: 'JAMS',
                          ),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'please enter JAMS';
                            }
                            return null;
                          },
                          // onSaved: ((newValue) {
                          //   _Customer_name = newValue! ;
                          // }
                          // ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 5),
                        child: CheckboxListTile(
                          // title: Text('2. Software version - '),
                          value: _No2_J,
                          onChanged: ((value) {
                            setState(() {
                              _No2_J = value!;
                            });
                          }),
                        ),
                      ),
                    ],
                  ),
                  TableRow(
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: TextFormField(
                          // initialValue: 'TUH',
                          //  readOnly: true,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(),
                            labelText: 'CLEW',
                            hintText: 'CLEW',
                          ),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'please enter CLEW';
                            }
                            return null;
                          },
                          // onSaved: ((newValue) {
                          //   _Customer_name = newValue! ;
                          // }
                          // ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 5),
                        child: CheckboxListTile(
                          // title: Text('2. Software version - '),
                          value: _No2_C,
                          onChanged: ((value) {
                            setState(() {
                              _No2_C = value!;
                            });
                          }),
                        ),
                      ),
                    ],
                  )
                ]),
              ),
                Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text('3. Visual inspection '),
              ),
              Padding(
                padding: const EdgeInsets.all(2.0),
                child: Table(
                  border: TableBorder.all(),
                  children: <TableRow>[
                  TableRow(
                    children: <Widget>[
                      
                      Padding(
                        padding: const EdgeInsets.only(top: 5),
                        child: CheckboxListTile(
                           title: Text('Verify that the display contrast is set so that the display is easily read. '),
                          value: _No3_a,
                          onChanged: ((value) {
                            setState(() {
                              _No3_a = value!;
                            });
                          }),
                        ),
                      ),
                    ],
                  ),
                  TableRow(
                    children: <Widget>[
                     
                      Padding(
                        padding: const EdgeInsets.only(top: 5),
                        child: CheckboxListTile(
                          title: Text('Verify cartridge door springs back. '),
                          value: _No3_b,
                          onChanged: ((value) {
                            setState(() {
                              _No3_b = value!;
                            });
                          }),
                        ),
                      ),
                    ],
                  )
                ]),
              ),
              
              
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: ElevatedButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        child: Text('Back')),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: ElevatedButton(
                        onPressed: () {
                                Navigator.push(context,
                          MaterialPageRoute(builder: (context)=> Checklist_istat_Page3()));
                        },
                        child: Text('Next')),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
