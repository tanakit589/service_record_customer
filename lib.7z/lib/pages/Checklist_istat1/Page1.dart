import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:service_record/pages/Checklist_istat1/Page2.dart';



class Checklist_istat_Page1 extends StatefulWidget {
  @override
  State<Checklist_istat_Page1> createState() => _Checklist_istat_Page1State();
}

class _Checklist_istat_Page1State extends State<Checklist_istat_Page1> {
   final _formkey = GlobalKey<FormState> ();
   late String _SerialNumber ;
   
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Checklist Page 1'),
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Center(child: Text('i-STAT1')),
          )
        ],
      ),
      body: SingleChildScrollView(
        child: Form(
           key: _formkey , 
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Center(
                    child: Text(
                  'Device Information',
                  style: TextStyle(fontSize: 20),
                )),
              ),
               Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: TextFormField(
                      // initialValue: 'TUH',
                    //  readOnly: true,
                      decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        labelText: 'Serial Number',
                        hintText: 'Serial Number',
                        ),
                    validator: (value) {
                      if (value == null || value.isEmpty ){
                        return 'please enter Serial Number';
                      }
                      return null;
                    },
                    // onSaved: ((newValue) {
                    //   _Customer_name = newValue! ;
                    // }
                    // ),
                     ),
                  ),
                   Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: TextFormField(
                       initialValue: 'TUH',
                      // readOnly: true,
                      decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        labelText: 'Hospital',
                        hintText: 'Hospital',
                        ),
                    validator: (value) {
                      if (value == null || value.isEmpty ){
                        return 'please enter Hospital';
                      }
                      return null;
                    },
                    // onSaved: ((newValue) {
                    //   _Customer_name = newValue! ;
                    // }
                    // ),
                     ),
                  ),
                   Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: TextFormField(
                       initialValue: 'OR',
                      // readOnly: true,
                      decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        labelText: 'Location',
                        hintText: 'Location',
                        ),
                    validator: (value) {
                      if (value == null || value.isEmpty ){
                        return 'please enter Location';
                      }
                      return null;
                    },
                    // onSaved: ((newValue) {
                    //   _Customer_name = newValue! ;
                    // }
                    // ),
                     ),
                  ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: ElevatedButton(onPressed: (){
                         
                         
                            Navigator.pop(context);
                          
                        }, 
                        child: Text('Back')),
                  ),
                   Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: ElevatedButton(onPressed: (){
                     
                     
                        Navigator.push(context,
                  MaterialPageRoute(builder: (context)=> Checklist_istat_Page2()));
                      
                    }, 
                    child: Text('Next')),
                  ),
                      ],
                    ),
                 
            ],
          ),
        ),
      ),
    );
  }
}
