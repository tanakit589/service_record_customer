
import 'package:flutter/material.dart';
import 'package:hand_signature/signature.dart';
import 'package:service_record/pages/service_report/Service_reportfull.dart';
import 'package:service_record/pages/service_report/service_reportpage4.dart';
import 'package:service_record/pages/service_report/service_reportpage5.dart';
import 'package:service_record/pages/service_report/service_reportpage6.dart';
import 'package:service_record/widgets/drawer.dart';
import 'package:flutter/services.dart';
import 'dart:async';
import 'package:provider/provider.dart';

ValueNotifier<String?> CusSign_Check = ValueNotifier<String?>(null);

final control = HandSignatureControl(
  threshold: 3.0,
  smoothRatio: 0.5,
  velocityRange: 2.0,
);

class Checklist_istat_Page5 extends StatefulWidget {
  @override
  State<Checklist_istat_Page5> createState() => _Checklist_istat_Page5State();
}

class _Checklist_istat_Page5State extends State<Checklist_istat_Page5> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        drawer: drawer(),
        appBar: AppBar(
          title: Text('Page5'),
        ),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: Align(
                  alignment: Alignment.center,
                  child: Text('Customer Signature')),
            ),
            Expanded(
              child: Center(
                child: Container(
                  constraints: BoxConstraints.expand(),
                  color: Colors.grey,
                  child: HandSignature(
                    control: control,
                    color: Colors.black,
                    width: 2,
                    maxWidth: 10,
                    type: SignatureDrawType.line,
                  ),
                ),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: ElevatedButton(
                    onPressed: () {
                      control.clear();
                      CusSign_Check.value = null;
                    },
                    child: Text('clear'),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: ElevatedButton(
                      onPressed: () async {
                        CusSign_Check.value = control.toSvg(
                            color: Colors.cyan,
                            size: Size(512, 256),
                            strokeWidth: 3.0,
                            maxStrokeWidth: 15.0,
                            type: SignatureDrawType.line);
                      },
                      child: Text('save')),
                )
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: Text('back')),
                ),
                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => testsign()));
                      },
                      child: Text('next')),
                ),
              ],
            ),
          ],
        ));
  }
}

class Signmodel extends ChangeNotifier{
  ValueNotifier<String?> CusSign_Check = ValueNotifier<String?>(null);
 ValueNotifier<String?> get getCusSign_Check => this.CusSign_Check;

 set setCusSign_Check(ValueNotifier<String?> CusSign_Check) { this.CusSign_Check = CusSign_Check;
 notifyListeners();
 }
}

class testsign extends StatefulWidget{
  @override
  State<testsign> createState() => _testsignState();
}

class _testsignState extends State<testsign> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        drawer: drawer(),
        appBar: AppBar(
          title: Text('Page5'),
        ),
        body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: Align(
                  alignment: Alignment.center,
                  child: Text('Customer Signature')),
            ),
            Container(
              width: 300.0,
              height: 300.0,
              decoration: BoxDecoration(
                border: Border.all(),
                color: Colors.white30,
              ),
              child: ValueListenableBuilder<String?>(
                valueListenable: CusSign_Check,
                builder: (context, data, child) {
                  return HandSignatureView.svg(
                    data: data,
                    padding: EdgeInsets.all(8.0),
                    placeholder: Container(
                      color: Colors.red,
                      child: Center(
                        child: Text('not signed yet (svg)'),
                      ),
                    ),
                  );
                },
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: Text('back')),
                ),
                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => service_reportPagefull()));
                      },
                      child: Text('next')),
                ),
              ],
            ),
          ],
        ));
  }
  }
