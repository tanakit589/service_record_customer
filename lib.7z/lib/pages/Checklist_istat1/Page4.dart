import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:service_record/pages/Checklist_istat1/Page5.dart';

class Checklist_istat_Page4 extends StatefulWidget {
  @override
  State<Checklist_istat_Page4> createState() => _Checklist_istat_Page4State();
}

class _Checklist_istat_Page4State extends State<Checklist_istat_Page4> {
  final _formkey = GlobalKey<FormState>();
  late String _Remarks;

  bool _No5_a = false;
  bool _No5_b = false;
  bool _No5_c = false;
  bool _No6 = false;
  bool _No7 = false;
  bool _No8 = false;


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Checklist Page 4'),
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Center(child: Text('i-STAT1')),
          )
        ],
      ),
      body: SingleChildScrollView(
        child: Form(
          key: _formkey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.all(2.0),
                child: Table(border: TableBorder.all(), children: <TableRow>[
                  TableRow(children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Text('5. Wake-up circuit test'),
                    ),
                  ]),
                  TableRow(
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.only(top: 5),
                        child: CheckboxListTile(
                          title: Text(
                              'With simulator installed, press the ON/OFF key to power down the analyzer.'),
                          value: _No5_a,
                          onChanged: ((value) {
                            setState(() {
                              _No5_a = value!;
                            });
                          }),
                        ),
                      ),
                    ],
                  ),
                  TableRow(
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.only(top: 5),
                        child: CheckboxListTile(
                          title: Text(
                              'Once the unit powered down, press the ON/OFF key to power up.'),
                          value: _No5_b,
                          onChanged: ((value) {
                            setState(() {
                              _No5_b = value!;
                            });
                          }),
                        ),
                      ),
                    ],
                  ),
                  TableRow(
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.only(top: 5),
                        child: CheckboxListTile(
                          title: Text(
                              'Verify that the analyzer powers up and the message, REMOVE CARTRIDGE appears on the screen.'),
                          value: _No5_c,
                          onChanged: ((value) {
                            setState(() {
                              _No5_c = value!;
                            });
                          }),
                        ),
                      ),
                    ],
                  ),
                ]),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 10, right: 2, left: 2),
                child: Container(
                  decoration: BoxDecoration(border: Border.all()),
                  child: CheckboxListTile(
                    title: Text(
                        '6. Check time & date and verify backlight operation by pressing 0 (Backlight) keys for 2 seconds.'),
                    value: _No6,
                    onChanged: ((value) {
                      setState(() {
                        _No6 = value!;
                      });
                    }),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 10, right: 2, left: 2),
                child: Container(
                  decoration: BoxDecoration(border: Border.all()),
                  child: CheckboxListTile(
                    title: Text('7. Verify Printer functionality '),
                    value: _No7,
                    onChanged: ((value) {
                      setState(() {
                        _No7 = value!;
                      });
                    }),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 10, right: 2, left: 2),
                child: Container(
                  decoration: BoxDecoration(border: Border.all()),
                  child: CheckboxListTile(
                    title: Text(
                        '8. Test run using electronics simulator x 2 times'),
                    value: _No8,
                    onChanged: ((value) {
                      setState(() {
                        _No8 = value!;
                      });
                    }),
                  ),
                ),
              ),
                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: TextFormField(
                      maxLines: 3,
                      //  initialValue: 'OR',
                      // readOnly: true,
                      decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        labelText: 'Remark',
                        hintText: 'Remark',
                        ),
                    validator: (value) {
                      if (value == null || value.isEmpty ){
                        return 'please enter Remark';
                      }
                      return null;
                    },
                    onSaved: ((newValue) {
                      _Remarks = newValue! ;
                    }
                    ),
                     ),
                  ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: ElevatedButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        child: Text('Back')),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: ElevatedButton(
                        onPressed: () {
                                Navigator.push(context,
                          MaterialPageRoute(builder: (context)=> Checklist_istat_Page5()));
                        },
                        child: Text('Next')),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
