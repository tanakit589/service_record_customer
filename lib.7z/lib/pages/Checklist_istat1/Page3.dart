import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:service_record/pages/Checklist_istat1/Page4.dart';

class Checklist_istat_Page3 extends StatefulWidget {
  @override
  State<Checklist_istat_Page3> createState() => _Checklist_istat_Page3State();
}

class _Checklist_istat_Page3State extends State<Checklist_istat_Page3> {
  final _formkey = GlobalKey<FormState>();
  

  bool _No4_a = false;
  bool _No4_b = false;
  bool _No4_c = false;
  bool _No4_d = false;
  bool _No4_e = false;
  bool _No4_f = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Checklist Page 3'),
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Center(child: Text('i-STAT1')),
          )
        ],
      ),
      body: SingleChildScrollView(
        child: Form(
          key: _formkey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: Text('4. Run simulator, check keys and scanner operation'),
              ),
             Padding(
                padding: const EdgeInsets.all(2.0),
                child: Table(
                  border: TableBorder.all(),
                  children: <TableRow>[
                  TableRow(
                    children: <Widget>[
                      
                      Padding(
                        padding: const EdgeInsets.only(top: 5),
                        child: CheckboxListTile(
                           title: Text('Insert Electronics Simulator. The analyzer cycle should begin upon Simulator insertion. '),
                          value: _No4_a,
                          onChanged: ((value) {
                            setState(() {
                              _No4_a = value!;
                            });
                          }),
                        ),
                      ),
                    ],
                  ),
                  TableRow(
                    children: <Widget>[
                     
                      Padding(
                        padding: const EdgeInsets.only(top: 5),
                        child: CheckboxListTile(
                          title: Text('Verify that keys operate properly by entering Operator # as follows: Press the 123456789.0 and ABC keys and left/right arrow to change the letter. '),
                          value: _No4_b,
                          onChanged: ((value) {
                            setState(() {
                              _No4_b = value!;
                            });
                          }),
                        ),
                      ),
                    ],
                  ),
                   TableRow(
                    children: <Widget>[
                     
                      Padding(
                        padding: const EdgeInsets.only(top: 5),
                        child: CheckboxListTile(
                          title: Text('Press the ABC key again, the cursor moves to the right.'),
                          value: _No4_c,
                          onChanged: ((value) {
                            setState(() {
                              _No4_c = value!;
                            });
                          }),
                        ),
                      ),
                    ],
                  ),
                  TableRow(
                    children: <Widget>[
                     
                      Padding(
                        padding: const EdgeInsets.only(top: 5),
                        child: CheckboxListTile(
                          title: Text('Verify that the left key clears (clear back till the display reads 123456789 and hit the ENTER key. )'),
                          value: _No4_d,
                          onChanged: ((value) {
                            setState(() {
                              _No4_d = value!;
                            });
                          }),
                        ),
                      ),
                    ],
                  ),
                  TableRow(
                    children: <Widget>[
                     
                      Padding(
                        padding: const EdgeInsets.only(top: 5),
                        child: CheckboxListTile(
                          title: Text('When prompted for the Simulator ID scan any bar code to verify that the scan works properly.'),
                          value: _No4_e,
                          onChanged: ((value) {
                            setState(() {
                              _No4_e = value!;
                            });
                          }),
                        ),
                      ),
                    ],
                  ),
                  TableRow(
                    children: <Widget>[
                     
                      Padding(
                        padding: const EdgeInsets.only(top: 5),
                        child: CheckboxListTile(
                          title: Text('Record PASS/FAIL indication from Electronic Simulator.'),
                          value: _No4_f,
                          onChanged: ((value) {
                            setState(() {
                              _No4_f = value!;
                            });
                          }),
                        ),
                      ),
                    ],
                  ),
                ]),
              ),
              
              
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: ElevatedButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        child: Text('Back')),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: ElevatedButton(
                        onPressed: () {
                                Navigator.push(context,
                          MaterialPageRoute(builder: (context)=> Checklist_istat_Page4()));
                        },
                        child: Text('Next')),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
