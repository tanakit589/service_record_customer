// ignore_for_file: deprecated_member_use

import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'dart:async';

import 'package:service_record/pages/CreateJob/Page2.dart';

class CreateJobPage1 extends StatefulWidget {
  @override
  State<CreateJobPage1> createState() => _CreateJobPage1State();
}

class _CreateJobPage1State extends State<CreateJobPage1> {
  final _formkey = GlobalKey<FormState>();
  late String _DeviceName;
   String _HospitalName='';
  late String _SerialNumber;
   String _Department='';
  late String _errorcode;

  File _imageFile = File('.');

  Future _getFromGallery() async {
    final pickedFile = await ImagePicker().getImage(
      source: ImageSource.gallery,
      maxWidth: 1800,
      maxHeight: 1800,
    );
    if (pickedFile != null) {
      setState(() {
        _imageFile = File(pickedFile.path);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Find error code '),
      ),
      body: SingleChildScrollView(
        child: Form(
          key: _formkey,
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextFormField(
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Serial Number',
                      hintText: 'Serial Number',
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'please enter Serial Number';
                      }
                      return null;
                    },
                    onSaved: ((newValue) {
                      _SerialNumber = newValue!;
                    }),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Container(
                    //width: 200,
                    child: TextFormField(
                      readOnly: true,
                      initialValue: '',
                      decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        labelText: 'Device Name',
                        hintText: 'Device Name',
                      ),
                      onSaved: ((newValue) {
                        _DeviceName = newValue!;
                      }),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Container(
                    //width: 140,
                    child: TextFormField(
                      initialValue: '',
                      readOnly: true,
                      decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        labelText: 'Hospital',
                        hintText: 'hospital',
                      ),
                      onChanged: ((newValue) {
                        _HospitalName = newValue;
                      }),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Container(
                    //width: 140,
                    child: TextFormField(
                      readOnly: true,
                      initialValue: '',
                      decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        labelText: 'Department',
                        hintText: 'Department',
                      ),
                      onChanged: ((newValue) {
                        _Department = newValue;
                      }),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextFormField(
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Error code',
                      hintText: 'Error code',
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'please enter error code';
                      }
                      return null;
                    },
                    onSaved: ((newValue) {
                      _errorcode = newValue!;
                    }),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: ElevatedButton(
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          child: Text('back')),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: ElevatedButton(
                          onPressed: () {
                            if (_formkey.currentState!.validate()) {
                              _formkey.currentState!.save();
                              context.read<CreateJobmodel>()
                                ..SerialNumber = _SerialNumber
                                ..errorcode = _errorcode
                                ..DeviceName= _DeviceName
                                ..HospitalName=_HospitalName
                                ..Department= _Department;

                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => CreateJobPage2()));
                            }
                          },
                          child: Text('next')),
                    ),
                  ],
                ),
                 Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: ElevatedButton(
                          onPressed: () {
                           

                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => CreateJobPage2()));
                            
                          },
                          child: Text('next test')),
                    ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class CreateJobmodel extends ChangeNotifier {
  String _DeviceName = '';
  String _HospitalName = '';
  String _SerialNumber = '';
  String _Department = '';
  String _errorcode = '';
  String _model = '';
  String _manufacturer = '';

 get model => this._model;

 set model( value) { this._model = value;
 notifyListeners();
 }

  get manufacturer => this._manufacturer;

 set manufacturer( value) { this._manufacturer = value;
 notifyListeners();}

  get DeviceName => this._DeviceName;

  set DeviceName(value) {
    this._DeviceName = value;
    notifyListeners();
  }

  get HospitalName => this._HospitalName;

  set HospitalName(value) {
    this._HospitalName = value;
    notifyListeners();
  }

  get SerialNumber => this._SerialNumber;

  set SerialNumber(value) {
    this._SerialNumber = value;
    notifyListeners();
  }

  get Department => this._Department;

  set Department(value) {
    this._Department = value;
    notifyListeners();
  }

  get errorcode => this._errorcode;

  set errorcode(value) {
    this._errorcode = value;
    notifyListeners();
  }
}
