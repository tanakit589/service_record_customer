import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:service_record/pages/CreateJob/Page1.dart';
import 'package:service_record/pages/CreateJob/Page2.dart';

class CreateJobPage3 extends StatefulWidget{
  @override
  State<CreateJobPage3> createState() => _CreateJobPage3State();
}

class _CreateJobPage3State extends State<CreateJobPage3> {
  
  File _imageFile = File('.');
  Future _getFromGallery() async {

   final pickedFile = await ImagePicker().getImage(
      source: ImageSource.gallery,
      maxWidth: 1800,
      maxHeight: 1800,
    );
    if (pickedFile != null) {
      setState(() {
        _imageFile  = File(pickedFile.path);
      });
    }
  }

   final _formkey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
   return Scaffold(
    appBar: AppBar(title: Text('Create Job '),),
    body: SingleChildScrollView(
      child: Form(
            key: _formkey,
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Consumer<CreateJobmodel>(
                builder: (context, value, child) {
                  
                return  Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: TextFormField(
                        initialValue: '${value.SerialNumber}',
                        decoration: InputDecoration(
                          border: OutlineInputBorder(),
                          labelText: 'Serial Number',
                          hintText: 'Serial Number',
                        ),
                        
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                        //width: 200,
                        child: TextFormField(
                          
                          readOnly: true,
                        initialValue: '${value.DeviceName}',
                          decoration: InputDecoration(
                            border: OutlineInputBorder(),
                            labelText: 'Device Name',
                            hintText: 'Device Name',
                          ),
                         
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                        //width: 140,
                        child: TextFormField(
                          initialValue: '${value.HospitalName}',
                          readOnly: true,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(),
                            labelText: 'Hospital',
                            hintText: 'hospital',
                          ),
                          
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                        //width: 140,
                        child: TextFormField(
                          
                          readOnly: true,
                         initialValue: '${value.Department}',
                          decoration: InputDecoration(
                            border: OutlineInputBorder(),
                            labelText: 'Department',
                            hintText: 'Department',
                          ),
                          
                          
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: TextFormField(
                        initialValue: '${value.errorcode}',
                        decoration: InputDecoration(
                          border: OutlineInputBorder(),
                          labelText: 'Error code',
                          hintText: 'Error code',
                        ),
                        
                      ),
                    ),
                     Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextFormField(
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Detail',
                      hintText: 'Detail',
                      labelStyle: TextStyle(fontSize: 20),
                    ),
                    maxLines: 7,
                    scrollPhysics: const BouncingScrollPhysics(),
                    onSaved: ((newValue) {
                    //    = newValue!;
                    }),
                  ),
                ),
                ElevatedButton.icon(onPressed: (){
                      _getFromGallery();
                  }, icon: Icon(Icons.image), label: Text('Add image')
                  ),
                  Container(
                    child: Image.file(
                      _imageFile,
                    fit: BoxFit.cover,
                    ),

                    
                  ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: ElevatedButton(onPressed: (){Navigator.pop(context);}, child: Text('back')),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: ElevatedButton(onPressed: (){
                        Navigator.popUntil(context, ModalRoute.withName('/homepage'));
                      }, child: Text('Create Job')),
                    ),
                    
                  ],
                )
                  ]
                );
                }
              )
            )
      ),
    )
   );
  }
}

