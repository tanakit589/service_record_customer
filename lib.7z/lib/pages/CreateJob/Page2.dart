// ignore_for_file: deprecated_member_use

import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:async';

import 'package:provider/provider.dart';
import 'package:service_record/pages/CreateJob/Page1.dart';
import 'package:service_record/pages/CreateJob/Page3.dart';

class CreateJobPage2 extends StatefulWidget {
  @override
  State<CreateJobPage2> createState() => _CreateJobPage2State();
}

class _CreateJobPage2State extends State<CreateJobPage2> {
  final _formkey = GlobalKey<FormState>();
  late String _errorcode;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Find error code '),
      ),
      body: SingleChildScrollView(
        child: Form(
          key: _formkey,
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Consumer<CreateJobmodel>(
                      builder: (context, value, child) {
                    return TextFormField(
                      initialValue: '${value.errorcode}',
                      decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        labelText: 'Error code',
                        hintText: 'Error code',
                        suffixIcon: IconButton(
                          icon: Icon(Icons.search),
                          onPressed: () {
                            setState(() {});
                          },
                        ),
                      ),
                      onChanged: ((newValue) {
                        setState(() {
                          _errorcode = newValue;
                        });
                      }),
                    );
                  }),
                ),
                Text('If cannot solve please goto create Job'),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: ElevatedButton(
                          onPressed: () {
                            Navigator.popUntil(
                                context, ModalRoute.withName('/homepage'));
                          },
                          child: Text('Go to Home')),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: ElevatedButton(
                          onPressed: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => CreateJobPage3()));
                          },
                          child: Text('Create Job')),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
