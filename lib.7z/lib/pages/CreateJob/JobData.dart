import 'dart:collection';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class JobdataModel extends ChangeNotifier {
 late String _DeviceName;
  late String _Contact;
  late String _HospitalName;
  late String _detail;
  late String _SerialNumber;
  late String _Typejob;
  late String _ContactNo;
   File _imageFile = File('.')   ;
  get DeviceName => this._DeviceName;

 set DeviceName( value) => this._DeviceName = value;

  get Contact => this._Contact;

 set Contact( value) => this._Contact = value;

  get HospitalName => this._HospitalName;

 set HospitalName( value) => this._HospitalName = value;

  get detail => this._detail;

 set detail( value) => this._detail = value;

  get SerialNumber => this._SerialNumber;

 set SerialNumber( value) => this._SerialNumber = value;

  get Typejob => this._Typejob;

 set Typejob( value) => this._Typejob = value;

  get ContactNo => this._ContactNo;

 set ContactNo( value) => this._ContactNo = value;

  get imageFile => this._imageFile;

 set imageFile( value) => this._imageFile = value;

}

class JobDataList extends ChangeNotifier{
late final List<JobdataModel> _listJobdataModel = [];
  void saveItem(JobdataModel itemData) {
   
    notifyListeners();
  }

  List<JobdataModel> get listItem {
    return _listJobdataModel;
  }
  
}
