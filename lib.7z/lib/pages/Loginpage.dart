import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class LoginPage extends StatefulWidget{
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
   final _formkey = GlobalKey<FormState> ();
  late String _username;
  late String _password;

  bool _hidePassword = true;
  bool _hideConfirmPassword = true;
  @override
  Widget build(BuildContext context) {
   return Scaffold(
    appBar: AppBar(
          //title: Text('ggg'),
        ),
        body: Form(
          key: _formkey,
          child: SingleChildScrollView(
              child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
           //  crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Container(
                //margin: EdgeInsets.only(top: 10.0),
                //decoration: BoxDecoration(
                //  borderRadius: BorderRadius.circular(14.0),
                //),
                child: Image.asset(
                  
                  'images/logo.png',
                  height: 250,
                  width: 400,
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
               
                children: [
                  
                  RichText(
                    text: TextSpan(
                        text: "Service System",
                        style: TextStyle(
                          fontSize: 20,
                          // fontStyle: FontStyle.italic,
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                        ),
                    ),
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextFormField(
                  decoration: InputDecoration(
                      labelText: 'Username',
                      border: OutlineInputBorder(),
                      hintText: 'Username'),
                  // validator: (value) {
                  //   if (value == null || value.isEmpty) {
                  //     return 'Please enter your User Name ';
                  //   } else if (value.length < 5 || value.length > 30) {
                  //     return "FirstName must be between 5-30 character length only";
                  //   } else {
                  //     return null;
                  //   }
                  // },
                  onSaved: ((newValue) {
                    _username = newValue!;
                  }),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextFormField(
                  obscureText: _hidePassword,
                  decoration: InputDecoration(
                      labelText: 'Password',
                      border: OutlineInputBorder(),
                      hintText: 'Password',
                      suffixIcon: IconButton(
                        onPressed: () {
                          setState(() {
                            _hidePassword = false;
                          });
                          Timer.periodic(
                            Duration(seconds: 5),
                            (Timer) {
                              setState(() {
                                _hidePassword = true;
                              });
                            },
                          );
                        },
                        icon: Icon(Icons.remove_red_eye),
                      )),
                  // validator: (value) {
                  //   if (value == null || value.isEmpty) {
                  //     return 'Please enter your ConfirmPassword  ';
                  //   } else if (value.length < 5 || value.length > 30) {
                  //     return "Confirm Password must be between 5-30 character length only";
                  //   } else if (value != _password) {
                  //     return 'Confirm password not matching';
                  //   } else {
                  //     return null;
                  //   }
                  // },
                   onSaved: ((newValue) {
                    _password = newValue!;
                  }),
                  
                ),
              ),
        
              ElevatedButton(
                onPressed: () {
                  if (_formkey.currentState!.validate()) {
                      _formkey.currentState!.save();
                    Navigator.pushNamed(context, '/homepage');
                    context.read<ProfileModel>()
                    ..username=_username
                    ..password=_password;
                  }
                },
                child: Text(
                  ' เข้าสู่ระบบ / Login ',
                  style: TextStyle(fontSize: 18),
                ),
               
                 
                
              ),
             
            ],
          ),
              ),
            ),
        )
   );
  }
}

class ProfileModel extends ChangeNotifier{
   String _username= '';
   String _password = '';

  get password => this._password;

 set password( value) { this._password = value;
 notifyListeners();
 }

  get username => this._username;

 set username( value) { this._username = value;
 notifyListeners();
 }
}