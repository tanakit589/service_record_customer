import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/material/colors.dart';
import 'package:service_record/pages/service_report/aaa.dart';
import 'package:service_record/pages/service_report/service_reportpage1.dart';
import 'package:service_record/pages/service_report/service_reportpage2.dart';
import 'package:service_record/pages/service_report/service_reportpage4.dart';
import 'package:service_record/pages/service_report/service_reportpage5.dart';
import 'package:service_record/widgets/drawer.dart';
import 'package:provider/provider.dart';

class service_reportPage3 extends StatefulWidget {
  @override
  State<service_reportPage3> createState() => _service_reportPageState();
}

class _service_reportPageState extends State<service_reportPage3> {
  final _formkey = GlobalKey<FormState>();
   String _Fault ='';
   String _WorkDone='';
   String _Remark= '';
  List<TextEditingController> _controllers = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: drawer(),
      appBar: AppBar(
        title: Text('Page 3'),
      ),
      body: SingleChildScrollView(
        child: Form(
          key: _formkey,
          child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text('Detail Report', style: TextStyle(fontSize: 16)),
                ),
                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: TextFormField(
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Fault',
                      hintText: 'Fault detail',
                      labelStyle: TextStyle(fontSize: 20),
                    ),
                    maxLines: 5,
                    scrollPhysics: const BouncingScrollPhysics(),
                    onSaved: ((newValue) {
                      _Fault = newValue!;
                    }),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextFormField(
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Work Done',
                      hintText: 'Work done detail',
                      labelStyle: TextStyle(fontSize: 20),
                    ),
                    maxLines: 7,
                    scrollPhysics: const BouncingScrollPhysics(),
                    onSaved: ((newValue) {
                      _WorkDone = newValue!;
                    }),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextFormField(
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Remark',
                      hintText: 'Remark detail',
                      labelStyle: TextStyle(fontSize: 20),
                    ),
                    maxLines: 7,
                    scrollPhysics: const BouncingScrollPhysics(),
                    onSaved: ((newValue) {
                      _Remark = newValue!;
                    }),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: ElevatedButton(
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          child: Text('back')),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: ElevatedButton(
                          onPressed: () {
                             if (_formkey.currentState!.validate()) {
                              _formkey.currentState!.save();
                           // context.read<DetailRepotModel>().Fault = _Fault;
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                        service_reportpage4()));
                            context.read<DetailRepotModel>()
                              ..Fault = _Fault
                              ..Remark = _Remark
                              ..WorkDone = _WorkDone;
                              print('${_Fault}, ${_Remark}, ${_WorkDone}');
                          }
                          },
                          child: Text('next')),
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: ElevatedButton(
                      onPressed: () {
                        //context.read<DetailRepotModel>().Fault=_Fault;
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => SparePart()));
                      },
                      child: Text('Spare Part')),
                ),
                Consumer<SparePartModel>(builder: (context, value, child) {
                  return Container(
                    height: 200,
                    child: ListView.builder(
                       
                      itemCount:
                          Provider.of<SparePartModel>(context).partnumbercount,
                      itemBuilder: (context, index) {
                        _controllers.add(new TextEditingController());
                        return Container(
                          margin: EdgeInsets.all(5),
                          child: Column(
                            children: [
                            
                              value.partnameField[index],
                             
                              value.partnumberField[index],
                            ],
                          ),
                        );
                      },
                    ),
                  );
                  ;
                }),
                 ElevatedButton(
                onPressed: () {
                   setState(() {
                    Provider.of<SparePartModel>(context, listen: false).clearData();
                   });
                },
                child: Text("clear"),
              ),

              ],
            ),
        ),
      ),
    );
  }
}

class DetailRepotModel extends ChangeNotifier {
  String _Fault = '';
  String _WorkDone = '';
  String _Remark = '';
  get Fault => this._Fault;

  set Fault(value) {
    this._Fault = value;
    notifyListeners();
  }

  get WorkDone => this._WorkDone;

  set WorkDone(value) {
    this._WorkDone = value;
    notifyListeners();
  }

  get Remark => this._Remark;

  set Remark(value) {
    this._Remark = value;
    notifyListeners();
  }
}

class SparePart extends StatefulWidget {
  @override
  State<SparePart> createState() => _SparePartState();
}

class _SparePartState extends State<SparePart> {
  List<TextEditingController> _partnumbercontrollers = [];
  List<TextField> _partnumberField = [];
  List<TextEditingController> _partnamecontrollers = [];
  List<TextField> _partnameField = [];

  final _okController = TextEditingController();
  // void dispose() {
  //   for (final controller in _partnumbercontrollers) {
  //     controller.dispose();
  //   }
  //   for (final controller in _partnamecontrollers) {
  //     controller.dispose();
  //   }

  //   // _okController.dispose();
  //   super.dispose();
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: drawer(),
      appBar: AppBar(
        title: Text('Spare Part'),
      ),
      body: SingleChildScrollView(
        child: Column(children: [
          Container(
            height: 50,
            child: ListTile(
              title: Icon(Icons.add),
              onTap: () {
                final _partnumber = TextEditingController();
                final _partname = TextEditingController();

                final partnumberField =
                    _generateTextField(_partnumber, "partnumber");
                final partnameField = _generateTextField(_partname, "partname");

                setState(() {
                  _partnumbercontrollers.add(_partnumber);
                  _partnamecontrollers.add(_partname);
                  _partnumberField.add(partnumberField);
                  _partnameField.add(partnameField);
                });
              },
            ),
          ),
          Column(
            children: [
              for (var i = 0; i < _partnumbercontrollers.length; i++)
                Container(
                  margin: EdgeInsets.all(5),
                  child: InputDecorator(
                    child: Column(
                      children: [
                        _partnumberField[i],
                        _partnameField[i],
                      ],
                    ),
                    decoration: InputDecoration(
                      labelText: i.toString(),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                    ),
                  ),
                ),
              ElevatedButton(
                onPressed: () {
                   for (int i = 0; i < _partnumbercontrollers.length; i++)
                  Provider.of<SparePartModel>(context, listen: false)
                      .addData(_partnumberField[i], _partnameField[i]);
                  print('${_partnumberField} / ${_partnameField}');
                  Navigator.pop(context);
                  
                },
                child: Text("save"),
              ),
              
            ],
          ),
        ]),
      ),
    );
  }
}

TextField _generateTextField(TextEditingController controller, String hint) {
  return TextField(
    controller: controller,
    decoration: InputDecoration(
      border: OutlineInputBorder(),
      labelText: hint,
    ),
  );
}



class SparePartModel extends ChangeNotifier {
  List _partnumberField = [];
  List _partnameField = [];

  get partnumberField => this._partnumberField;

  set partnumberField(value) {
    this._partnumberField = value;
    notifyListeners();
  }

  get partnameField => this._partnameField;

  set partnameField(value) {
    this._partnameField = value;
    notifyListeners();
  }

  int get partnumbercount {
    return _partnumberField.length;
  }

  void addData(TextField partnumberField,TextField partnameField) {
    _partnumberField.add(partnumberField);
    _partnameField.add(partnameField);
    notifyListeners();
  }

  void clearData() {
    _partnumberField.clear();
    _partnameField.clear();
    notifyListeners();
  }
}
