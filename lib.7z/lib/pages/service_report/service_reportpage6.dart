import 'package:flutter/material.dart';
import 'package:hand_signature/signature.dart';
import 'package:service_record/pages/service_report/homepage_report.dart';
import 'package:service_record/pages/service_report/service_reportpage4.dart';
import 'package:service_record/pages/service_report/service_reportpage6.dart';

import 'package:service_record/widgets/drawer.dart';
import 'package:flutter/services.dart';
import 'dart:async';
import 'package:provider/provider.dart';

ValueNotifier<String?> EnSign = ValueNotifier<String?>(null);

final control = HandSignatureControl(
  threshold: 3.0,
  smoothRatio: 0.5,
  velocityRange: 2.0,
);

class service_reportpage6 extends StatefulWidget {
  @override
  State<service_reportpage6> createState() => _service_reportpage6State();
}

class _service_reportpage6State extends State<service_reportpage6> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        drawer: drawer(),
        appBar: AppBar(
          title: Text('Page6'),
        ),
        body: SingleChildScrollView(
          child: Stack(children: [
            Container(
              
              child: Image.asset('images/image1.jpg',)
               ),
          ],
          ),
          )
        );
  }
}

