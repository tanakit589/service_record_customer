import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/src/material/colors.dart';
import 'package:hand_signature/signature.dart';
import 'package:service_record/pages/service_report/Service_reportfull.dart';
import 'package:service_record/pages/service_report/service_reportpage5.dart';
import 'package:service_record/pages/service_report/service_reportpage1.dart';
import 'package:service_record/pages/service_report/service_reportpage2.dart';
import 'package:service_record/pages/service_report/service_reportpage4.dart';
import 'package:service_record/pages/service_report/service_reportpage6.dart';
import 'package:service_record/widgets/drawer.dart';
import 'package:provider/provider.dart';

class service_reportpage5 extends StatefulWidget {
  @override
  State<service_reportpage5> createState() => _service_reportpage5State();
}

class _service_reportpage5State extends State<service_reportpage5> {
  final _formkey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        drawer: drawer(),
        appBar: AppBar(
          title: Text('Page5'),
        ),
        body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: Align(
                  alignment: Alignment.center,
                  child: Text('Customer Signature')),
            ),
            Container(
              width: 300.0,
              height: 300.0,
              decoration: BoxDecoration(
                border: Border.all(),
                color: Colors.white30,
              ),
              child: ValueListenableBuilder<String?>(
                valueListenable: CusSign,
                builder: (context, data, child) {
                  return HandSignatureView.svg(
                    data: data,
                    padding: EdgeInsets.all(8.0),
                    placeholder: Container(
                      color: Colors.red,
                      child: Center(
                        child: Text('not signed yet (svg)'),
                      ),
                    ),
                  );
                },
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: Text('back')),
                ),
                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => service_reportPagefull()));
                      },
                      child: Text('next')),
                ),
              ],
            ),
          ],
        ));
  }
}