
import 'package:flutter/material.dart';
import 'package:hand_signature/signature.dart';
import 'package:service_record/pages/service_report/Service_reportfull.dart';
import 'package:service_record/pages/service_report/service_reportpage4.dart';
import 'package:service_record/pages/service_report/service_reportpage5.dart';
import 'package:service_record/pages/service_report/service_reportpage6.dart';
import 'package:service_record/widgets/drawer.dart';
import 'package:flutter/services.dart';
import 'dart:async';
import 'package:provider/provider.dart';

ValueNotifier<String?> CusSign = ValueNotifier<String?>(null);

final control = HandSignatureControl(
  threshold: 3.0,
  smoothRatio: 0.5,
  velocityRange: 2.0,
);

class service_reportpage4 extends StatefulWidget {
  @override
  State<service_reportpage4> createState() => _service_reportpage4State();
}

class _service_reportpage4State extends State<service_reportpage4> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        drawer: drawer(),
        appBar: AppBar(
          title: Text('Page4'),
        ),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: Align(
                  alignment: Alignment.center,
                  child: Text('Customer Signature')),
            ),
            Expanded(
              child: Center(
                child: Container(
                  constraints: BoxConstraints.expand(),
                  color: Colors.grey,
                  child: HandSignature(
                    control: control,
                    color: Colors.black,
                    width: 2,
                    maxWidth: 10,
                    type: SignatureDrawType.line,
                  ),
                ),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: ElevatedButton(
                    onPressed: () {
                      control.clear();
                      CusSign.value = null;
                    },
                    child: Text('clear'),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: ElevatedButton(
                      onPressed: () async {
                        CusSign.value = control.toSvg(
                            color: Colors.cyan,
                            size: Size(512, 256),
                            strokeWidth: 3.0,
                            maxStrokeWidth: 15.0,
                            type: SignatureDrawType.line);
                      },
                      child: Text('save')),
                )
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: Text('back')),
                ),
                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => service_reportPagefull()));
                      },
                      child: Text('next')),
                ),
              ],
            ),
          ],
        ));
  }
}

class Signmodel extends ChangeNotifier{
  ValueNotifier<String?> CusSign = ValueNotifier<String?>(null);
 ValueNotifier<String?> get getCusSign => this.CusSign;

 set setCusSign(ValueNotifier<String?> CusSign) { this.CusSign = CusSign;
 notifyListeners();
 }
}