import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:service_record/Controller/Device_controller.dart';
import 'package:service_record/Controller/Hospital_controller.dart';
import 'package:service_record/Model/Device.dart';
import 'package:service_record/Model/Hospital_Model.dart';
import 'package:service_record/Service/Device_service.dart';
import 'package:service_record/Service/hospital_service.dart';

class List_Device extends StatefulWidget{

  @override
  State<List_Device> createState() => _List_DeviceState();
}

class _List_DeviceState extends State<List_Device> {

  bool isLoading=false;
List<Device> device = List.empty();
DeviceController controller = DeviceController(DeviceService());
void initState(){
 super.initState();
    controller.onSync.listen((bool syncState) => setState(() {
      isLoading = syncState;
    }));
    _getdeviceInfo();
}
 void _getdeviceInfo() async {
    var newdevice = await controller.fetchdeviceInfo();
    setState(() => device = newdevice);
  }

  Widget  get body => isLoading 
    ? CircularProgressIndicator() 
    : ListView.builder(
        itemCount: !device.isEmpty ? device.length : 1,
        itemBuilder: (context, index) {
           if(!device.isEmpty){
          return InkWell(
            onTap: (){
              context.read<DeviceModel>().DeviceName= '${device[index].name}';
              // context.read<DrawModel>().drawId= '${hospital[index].drawId}';
               Navigator.pop(context, '${device[index].name}' ); 
               print ('${device[index].name}');
              
          
          },
            child: Container(
                  padding: const EdgeInsets.all(8.0),
                  height: 50 ,
                  
                  child: Center(child: Text('${device[index].name}')),
                ),
          );
           }
              else{
              return Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('Tap button to fetch todos'),
                ],
              );
           }
           }

    
        
     );
  @override
  Widget build(BuildContext context) {
   return Scaffold(
    appBar: AppBar(
      title: Text('Choose Device Name'),
    ),
    body: Center(child: body)
 
   ); 
  }
}

class DeviceModel extends ChangeNotifier{
  String _DeviceName ='';
 String get DeviceName => this._DeviceName;

 set DeviceName(String value) { this._DeviceName = value;
 notifyListeners();
 }

}