import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:service_record/Controller/Hospital_controller.dart';
import 'package:service_record/Model/Hospital_Model.dart';
import 'package:service_record/Service/hospital_service.dart';

class List_Hospital extends StatefulWidget{

  @override
  State<List_Hospital> createState() => _List_HospitalState();
}

class _List_HospitalState extends State<List_Hospital> {
  bool isLoading=false;
List<Hospital> hospital = List.empty();
HospitalController controller = HospitalController(HospitalService());
void initState(){
 super.initState();
    controller.onSync.listen((bool syncState) => setState(() {
      isLoading = syncState;
    }));
    _getHospitalInfo();
}
 void _getHospitalInfo() async {
    var newhospital = await controller.fetchhospitalInfo();
    setState(() => hospital = newhospital);
  }

  Widget  get body => isLoading 
    ? CircularProgressIndicator() 
    : ListView.builder(
        itemCount: !hospital.isEmpty ? hospital.length : 1,
        itemBuilder: (context, index) {
           if(!hospital.isEmpty){
          return InkWell(
            onTap: (){
              context.read<HospitalModel>().hospitalName= '${hospital[index].name}';
              // context.read<DrawModel>().drawId= '${hospital[index].drawId}';
               Navigator.pop(context, '${hospital[index].name}' ); 
               print ('${hospital[index].name}');
              
          
          },
            child: Container(
                  padding: const EdgeInsets.all(8.0),
                  height: 50 ,
                  
                  child: Center(child: Text('${hospital[index].name}')),
                ),
          );
           }
              else{
              return Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('Tap button to fetch todos'),
                ],
              );
           }
           }

    
        
     );
  @override
  Widget build(BuildContext context) {
   return Scaffold(
    appBar: AppBar(
      title: Text('Choose Hospital'),
    ),
    body: Center(child: body)
 
   ); 
  }
}

class HospitalModel extends ChangeNotifier{
  String _hospitalName ='';
 String get hospitalName => this._hospitalName;

 set hospitalName(String value) { this._hospitalName = value;
 notifyListeners();
 }

}