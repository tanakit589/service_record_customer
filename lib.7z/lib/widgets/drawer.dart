import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:service_record/pages/HomePage.dart';
import 'package:service_record/pages/Loginpage.dart';
import 'package:service_record/pages/add_device/page1.dart';
import 'package:service_record/pages/edit_data_device/edit_page1.dart';
import 'package:service_record/pages/service_report/Service_reportfull.dart';

class drawer extends StatefulWidget {
  @override
  State<drawer> createState() => drawerState();
}

class drawerState extends State<drawer> {
  @override
  Widget build(BuildContext context) {
    // print(MediaQuery.of(context).size); // สำหรับทดสอบ ดูความกว้าง สูง หน้าจอ
    return Drawer(
      child: ListView(
        children: [
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: Container(
              height: 100,
              color: Colors.green,
              child:  DrawerHeader(
                child: Center(
                    child: Consumer<ProfileModel>(
                      builder: (context, value, child) {
                    return Text(
                  '${value.username}',
                  style: TextStyle(fontSize: 18),
                    );
                    }
                    )
                ),
              ),
            ),
          ),
          ListTile(
            title: IconButton(
              onPressed: () => Navigator.popUntil(context, ModalRoute.withName('/homepage')),
              icon: Icon(Icons.home),
            ),
          ),
          ListTile(
            title: Center(child: const Text('Add device information')),
            onTap: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => AddDevice_Page1()));
            },
          ),
           ListTile(
            title: Center(child: const Text('Edit device information ')),
            onTap: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => EditPage1()));
            },
          ),
          ListTile(
            title: Center(child: const Text('history')),
            onTap: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => service_reportPagefull()));
            },
          ),
          ListTile(
            title: Center(
                child: const Text(
              'log out',
            )),
            onTap: () {
              Navigator.popUntil(context, ModalRoute.withName('/login'));
            },
          ),
        ],
      ),
    );
  }
}
