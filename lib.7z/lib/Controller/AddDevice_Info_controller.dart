import 'dart:async';

import 'package:service_record/Model/AddDevice_Info_model.dart';
import 'package:service_record/Service/AddDevice_Info_service.dart';

class AddDeviceController{
  final AddDeviceService services;
  List<AddDevice> addDevices = List.empty();

  StreamController<bool> onSyncController= StreamController();
  Stream<bool> get onSync => onSyncController.stream;

  AddDeviceController(this.services);

  Future<List<AddDevice>> fetchDeviceInfo() async{
    onSyncController.add(true);
    addDevices = await services.getDevice_InforInfo();
    onSyncController.add(false);
    return addDevices;

  }
 void addDevice(String date,sn,deviceName,model,
  manufacturer,hospital,department,contact ) async{
    services.addDevice( date, sn, deviceName, model, manufacturer, hospital, department, contact);
  }
}